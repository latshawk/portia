Welcome to Portia's documentation!
==================================

Contents:

.. toctree::
   :maxdepth: 2

   installation
   getting-started
   examples
   projects
   spiders
   samples
   items
   faq

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
