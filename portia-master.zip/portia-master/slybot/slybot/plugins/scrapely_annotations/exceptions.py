class MissingRequiredError(Exception):
    pass


class ItemNotValidError(Exception):
    pass
