==============
Slybot crawler
==============

Slybot is a Python web crawler for doing web scraping. It's implemented on top of the
`Scrapy`_ web crawling framework and the `Scrapely`_ extraction library.

The documentation (including installation and usage) can be found at:
http://slybot.readthedocs.org/

.. _Scrapely: https://github.com/scrapy/scrapely
.. _Scrapy: http://scrapy.org
