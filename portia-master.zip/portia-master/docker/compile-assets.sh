#!/bin/bash
cd portiaui
npm install
npm run build
