import validateRange from '../validators/range';

export default {
  value: validateRange()
};
