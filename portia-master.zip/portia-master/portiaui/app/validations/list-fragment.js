import { validatePresence } from 'ember-changeset-validations/validators';

export default {
  value: validatePresence(true)
};
