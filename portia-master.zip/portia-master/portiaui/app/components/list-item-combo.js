import ListItemSelectable from './list-item-selectable';

export default ListItemSelectable.extend({
    classNames: ['list-item-combo'],

    autoSelect: false
});
