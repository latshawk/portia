import ColoredBadge from './colored-badge';

export default ColoredBadge.extend({
});
