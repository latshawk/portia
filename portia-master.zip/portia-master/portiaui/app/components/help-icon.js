import Ember from 'ember';

export default Ember.Component.extend({
    tagName: '',

    tooltipClasses: null,
    tooltipContainer: 'body',
    placement: 'right',
    icon: 'help',
    classes: 'help-icon',
});
