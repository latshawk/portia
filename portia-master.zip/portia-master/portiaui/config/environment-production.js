/* jshint node: true */

module.exports = function(ENV) {
    return ENV;
};